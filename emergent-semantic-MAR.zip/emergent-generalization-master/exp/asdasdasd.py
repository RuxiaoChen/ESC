import torch
import numpy as np

# Load your adjacency matrix (replace this with your data loading logic)
adj_matrix_np = np.array([[0, 1, 0], [1, 0, 1], [0, 1, 0]])

# Convert the NumPy array to a PyTorch sparse tensor
adj_matrix_sparse = torch.sparse.FloatTensor(
    torch.LongTensor(np.where(adj_matrix_np)),
    torch.FloatTensor(adj_matrix_np[np.where(adj_matrix_np)])
)

# Convert the sparse tensor to a dense tensor
adj_matrix_dense = adj_matrix_sparse.to_dense()

print(adj_matrix_dense)
