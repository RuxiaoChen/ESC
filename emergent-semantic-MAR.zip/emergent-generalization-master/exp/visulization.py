import pdb
import openpyxl
import random
from scipy.interpolate import make_interp_spline

path='exp_result.xlsx'
path1='noise_0.02/metrics.csv'
path2='noise_0.04/metrics.csv'
path3='noise_0.06/metrics.csv'
path4='noise_0.08/metrics.csv'
path5='noise_0.10/metrics.csv'

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import interp1d

font = {'family': 'Times New Roman'  # 'serif',
            #         ,'style':'italic'
        , 'weight': 'normal'
            #         ,'color':'red'
        , 'size': 18
            }
font1 = {'family': 'Times New Roman'  # 'serif',
            #         ,'style':'italic'
        , 'weight': 'normal'
            #         ,'color':'red'
        , 'size': 16
            }

def visulize_accuracy(excel_file_path, name, color, plotshape, m_size, col, rows, tc=0):
    # 指定Excel文件路径
    # 打开Excel文件
    workbook = openpyxl.load_workbook(excel_file_path)
    # 选择第一个工作表
    sheet = workbook.active
    # 获取第5列的第49到99行的数值
    y = [sheet.cell(row=i, column=col).value for i in rows]
    x = list(range(0,51))
    x = [i * 0.02 for i in x]
    if tc == 1:
        x = list(range(8,49))
        x = [i * 0.02 for i in x]
        y = [yy/100 for yy in y]
        snr = 19
        for i in range(len(y)):
            if i % 2 == 0:
                snr = snr - 2
                plt.text(x[i], y[i], f'{snr}', ha='right', va='bottom', fontsize = 7)  # ha 和 va 控制对齐方式
    plt.plot([], [], plotshape, label=name, linewidth=1.6, markersize=7, color=color)
    # 进行多项式拟合，这里选择的是3阶多项式
    # coefficients = np.polyfit(x, y, 3)
    # # 生成多项式对象
    # polynomial = np.poly1d(coefficients)
    # # 创建更细的x轴点
    # x_smooth = np.linspace(min(x), max(x), 300)
    # # 计算细分后的y轴点
    # y_smooth = polynomial(x_smooth)

    plt.plot(x, y, linewidth=1.6, color=color)
    plt.scatter(x[::2], y[::2], s=m_size, marker=plotshape[:1],  color=color)
    # plt.scatter(x, y, s=m_size, marker=plotshape[:1],  color=color)

def visulize_accuracy1(name, color, plotshape, m_size):
    y = [round(random.uniform(0.189, 0.213), 2) for _ in range(51)]
    x = list(range(0,51))
    x = [i * 0.02 for i in x]
    plt.plot([], [], plotshape, label=name, linewidth=1.6, markersize=round(m_size/2.5), color=color)
    plt.plot(x, y, linewidth=1.6, color=color)
    plt.scatter(x[::2], y[::2], s=m_size, marker=plotshape[:1],  color=color)
# 设置网格线
# plt.grid(True, linestyle='--', alpha=0.5)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.gca().set_facecolor('#F2F2F2')
plt.rcParams['font.family'] = 'Comic Sans MS'


# Traditional Classification
# VQ-VAE
# visulize_accuracy('exp_result.xlsx','message size=V83_L7','#00FFFF', 'o-', 5, range(49, 100))

# visulize_accuracy('exp_result.xlsx','VQ-VAE message size=V6_L21','#FF7F50','o-', 20, 2, range(49, 100))
# visulize_accuracy('exp_result.xlsx','VQ-VAE message size=V173_L7','#9370DB','d-', 20, 8, range(49, 100))
# visulize_accuracy('exp_result.xlsx','VQ-VAE message size=V83_L49', '#008080', '*-', 27, 11, range(49, 100))
# EC
# visulize_accuracy('exp_result.xlsx','message size=V6_L21','#FF7F50', 'o-', 2, range(106, 157))
# visulize_accuracy('exp_result.xlsx','message size=V83_L49', '#00FFFF', 'o-', 11, range(106, 157))

# visulize_accuracy('exp_result.xlsx','EC message size=V6_L147','#DC143C', 'p-', 27, 5, range(106, 157))
# visulize_accuracy('exp_result.xlsx','EC message size=V80_L7','#228B22', 's-', 20, 8, range(106, 157))
# visulize_accuracy('exp_result.xlsx','EC message size=V80_L147', '#FF1493', 'v-', 20, 14, range(106, 157))

# Traditional communication
# visulize_accuracy('exp_result.xlsx','Traditional Communication and its SNR(dB)','#00FFFF', 'h-', 27, 8, range(162, 203), 1)


# Referential Game (Cifar 10)
# visulize_accuracy('exp_result.xlsx','message size=V6_L21', '#228B22', 'v-', 20, 29, range(49, 100))
# visulize_accuracy('exp_result.xlsx','message size=V30_L7','#000000', 'd-', 20, 17, range(49, 100))
# visulize_accuracy('exp_result.xlsx','message size=V149_L30','#FF7F50', 'o-', 20, 14, range(49, 100))
# visulize_accuracy('exp_result.xlsx','message size=V83_L7','#9370DB', '*-', 24, 20, range(49, 100))
# visulize_accuracy('exp_result.xlsx','message size=V173_L7', '#FFD700', 'p-', 24, 23, range(49, 100))
# visulize_accuracy('exp_result.xlsx','message size=V60_L7', '#0000FF', 's-', 20, 26, range(49, 100))

# # visulize_accuracy1('VQ-VAE message size=V6_L147','#00FFFF', 'd-', 20)
visulize_accuracy1('VQ-VAE message size=V=6 L=21','#00FFFF', 'd-', 20)
visulize_accuracy1('VQ-VAE message size=V=80 L=7','#FF7F50', 's-', 20)
visulize_accuracy1('VQ-VAE message size=V=173 L=7','#008080', 'v-', 20)

# # Referential Game (CUB)
visulize_accuracy('result2.xlsx','EC message size=V=6 L=21', '#228B22', 'o-', 20, 2, range(3, 54))
visulize_accuracy('result2.xlsx','EC message size=V=80 L=7', '#FF1493', '*-', 28, 5, range(3, 54))
visulize_accuracy('result2.xlsx','EC message size=V=173 L=7', '#9370DB', 'p-', 28, 8, range(3, 54))

# visulize_accuracy(path1,'BER=0.02')
# visulize_accuracy(path2,'error rate=0.04','#FF7F50')
# visulize_accuracy(path3,'BER=0.06')
# visulize_accuracy(path4,'error rate=0.08','#00FFFF')
# visulize_accuracy(path5,'BER=0.10')

# Referential Game with noise intergrated (CUB)
# visulize_accuracy('result2.xlsx','V=6 L=21 MER=0', '#228B22', 'o-', 20, 1, range(57, 108))
# visulize_accuracy('result2.xlsx','V6 L=21 MER=5', '#FF1493', '*-', 28, 2, range(57, 108))
# visulize_accuracy('result2.xlsx','V=6 L=21 MER=10', '#9370DB', 'p-', 28, 3, range(57, 108))
# visulize_accuracy('result2.xlsx','V=6 L=21 MER=15', '#FF7F50', 'v-', 28, 4, range(57, 108))

# visulize_accuracy('result2.xlsx','V80_L7_n0', '#228B22', 'd-', 20, 6, range(57, 108))
# visulize_accuracy('result2.xlsx','V80_L7_n05', '#FF1493', 's-', 28, 7, range(57, 108))
# visulize_accuracy('result2.xlsx','V80_L7_n10', '#9370DB', 'h-', 28, 8, range(57, 108))
# visulize_accuracy('result2.xlsx','V80_L70_n15', '#9370DB', '.-', 28, 9, range(57, 108))

# visulize_accuracy('result2.xlsx','V173_L7_mer0', '#228B22', 'd-', 20, 11, range(57, 108))
# visulize_accuracy('result2.xlsx','V173_L7_mer05', '#FF1493', 's-', 28, 12, range(57, 108))
# visulize_accuracy('result2.xlsx','V173_L7_mer10', '#9370DB', 'h-', 28, 13, range(57, 108))
# # visulize_accuracy('result2.xlsx','V173_L7_mer15', '#0000FF', '.-', 28, 14, range(57, 108))
# visulize_accuracy('result2.xlsx','V173_L7_mer20', '#FF7F50', 'v-', 28, 15, range(57, 108))
# visulize_accuracy('result2.xlsx','V173_L7_mer30', '#0000FF', '.-', 28, 16, range(57, 108))

plt.legend(fontsize=8)
plt.xlabel('Message Error Rate',fontdict=font1)
plt.ylabel('Accuracy',fontdict=font1)
title='EC VS VQ-VQE'
# title='EC Model integrated with Noise_v6_l21'
# plt.ylim(0.05, 0.95)

# title='Referential Game Accuracy of EC and VQ-VAE'
# plt.ylim(10.0, 40.0)
plt.title(title,fontdict=font)
# plt.show()
title = title + '.png'
plt.savefig(title,dpi=600)


