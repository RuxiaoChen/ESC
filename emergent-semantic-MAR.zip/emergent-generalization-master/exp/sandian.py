import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

path0='channel_nonoise/sampled_lang_force_concept_'
path1='noise_0.02/sampled_lang_force_concept_'
path2='noise_0.04/sampled_lang_force_concept_'
path3='noise_0.06/sampled_lang_force_concept_'
path4='noise_0.08/sampled_lang_force_concept_'
path5='noise_0.10/sampled_lang_force_concept_'

font = {'family': 'Times New Roman'  # 'serif',
            #         ,'style':'italic'
        , 'weight': 'normal'
            #         ,'color':'red'
        , 'size': 18
            }
font1 = {'family': 'Times New Roman'  # 'serif',
            #         ,'style':'italic'
        , 'weight': 'normal'
            #         ,'color':'red'
        , 'size': 16
            }

def find_mean(path,current_number,nrowss,skip=1):
    current_number=str(current_number)+'.csv'
    path=path+current_number
    # 提取需要的所有acc值
    df = pd.read_csv(path, usecols=[2], skiprows=skip, nrows=nrowss)
    y = df.iloc[:, 0]
    # 计算平均值
    mean = np.mean(y)
    return mean

def find_all(path,current_number,nrowss):
    current_number=str(current_number)+'.csv'
    path=path+current_number
    # 提取需要的所有acc值
    df = pd.read_csv(path, usecols=[2], skiprows=1, nrows=nrowss)
    y = df.iloc[:, 0]
    return y

def plot_noisy_level(dots,label,color,marker,size=7):
    x=[0, 0.02, 0.04, 0.06, 0.08, 0.10]
    plt.plot(x, dots, label=label, linewidth=2, color=color,marker=marker,markersize=size)
    # plt.scatter(x, dots, , c=color, marker=marker)


title1 = 'Average accuracy variation with message error rate (seen)'
title2 = 'Average accuracy variation with message error rate(unseen)'
def big_draw(title,nrows,yl1,yl2):
    all_path = [path0, path1, path2, path3, path4, path5]
    noise_level = [0, 2, 4, 6, 8, 10]
    average = []
    for path_name in all_path:
        for i in noise_level:
            mean_y = find_mean(path_name, i, nrows)
            average.append(mean_y)
    plot_noisy_level(average[0:6], 'no noise model', '#069AF3', 'v')
    plot_noisy_level(average[6:12], 'error rate=0.02', '#FF7F50', 'o')
    plot_noisy_level(average[12:18], 'error rate=0.04', '#00FFFF', 's')
    plot_noisy_level(average[18:24], 'error rate=0.06', 'limegreen', '*', size=9)
    plot_noisy_level(average[24:30], 'error rate=0.08', 'khaki', 'd')
    plot_noisy_level(average[30:36], 'error rate=0.10', 'teal', '+', size=9)
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)
    plt.gca().set_facecolor('#F2F2F2')
    plt.rcParams['font.family'] = 'Comic Sans MS'
    plt.xlabel('Message error rate', fontdict=font1)
    plt.ylabel('Accuracy', fontdict=font1)
    plt.ylim(yl1, yl2)
    plt.xlim(0, 0.1)
    plt.title(title, fontdict=font)
    plt.legend()
    title = title + '.png'
    plt.savefig(title, dpi=600)

big_draw(title1,700,0.6,0.8)
big_draw(title2,1000,0.58,0.75)


def boxploo_draw(title,nrows):
    all_path = [path0, path1, path2, path3, path4, path5]
    noise_level = [0, 2, 4, 6, 8, 10]
    average = []
    for path_name in all_path:
        for i in noise_level:
            mean_y = find_mean(path_name, i, nrows,skip=600)
            average.append(mean_y)

    data = [average[0:6], average[6:12], average[12:18], average[18:24], average[24:30], average[30:36]]

    # 设置箱线图的样式
    boxprops = {'facecolor': 'lightblue', 'color': 'navy'}
    # flierprops = {'marker': 'o', 'markerfacecolor': 'red', 'markersize': 5}
    whiskerprops = {'color': 'gray'}
    capprops = {'color': 'black'}
    medianprops = {'color': 'darkblue'}

    # 绘制箱线图
    fig, ax = plt.subplots()
    boxplot = ax.boxplot(data, patch_artist=True, boxprops=boxprops, flierprops=dict(marker=''), whiskerprops=whiskerprops,
                         capprops=capprops, medianprops=medianprops)

    # 设置图表标题和坐标轴标签
    ax.set_title('Box Plot')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')



    # 去除上边框和右边框
    # ax.spines['top'].set_visible(False)
    # ax.spines['right'].set_visible(False)

    # 设置坐标轴刻度的样式
    ax.tick_params(axis='both', direction='out', length=4, width=1, color='gray')

    # 增加网格线
    ax.grid(axis='y', linestyle='--', alpha=0.5)

    # 调整图表布局
    plt.tight_layout()

    # 设置箱线的颜色
    for patch in boxplot['boxes']:
        patch.set_facecolor('lightblue')

    # 显示图表
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)
    plt.gca().set_facecolor('#F2F2F2')
    plt.xlabel('Models trained under different message error rate', fontdict=font1)
    plt.ylabel('Accuracy', fontdict=font1)
    plt.title(title, fontdict=font)
    ax.set_xticklabels(['0.00','0.02', '0.04', '0.06', '0.08','0.10'])  # 设置刻度标签
    title = title + '.png'
    plt.savefig(title, dpi=600)

boxploo_draw('Box line chart of generalization accuracy',400)

