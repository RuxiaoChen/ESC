import numpy as np
import matplotlib.pyplot as plt

# 生成随机数据
np.random.seed(0)
data1 = np.random.randn(100, 2) + np.array([0, -2])
data2 = np.random.randn(100, 2) + np.array([2, 2])
data3 = np.random.randn(100, 2) + np.array([-2, 2])
data = np.vstack((data1, data2, data3))

# K-Means算法实现
def k_means(data, k, max_iters=100):
    # 随机初始化簇中心
    centers = data[np.random.choice(data.shape[0], k, replace=False), :]

    for _ in range(max_iters):
        # 指派数据点到最近的簇中心
        labels = np.argmin(np.linalg.norm(data[:, np.newaxis] - centers, axis=2), axis=1)

        # 更新簇中心
        new_centers = np.array([data[labels == i].mean(axis=0) for i in range(k)])

        # 如果簇中心不再改变，则结束
        if np.all(centers == new_centers):
            break

        centers = new_centers

    return centers, labels

# 应用K-Means算法
k = 3
centers, labels = k_means(data, k)

# 可视化结果
plt.scatter(data[:, 0], data[:, 1], c=labels, cmap='viridis', marker='o')
plt.scatter(centers[:, 0], centers[:, 1], c='red', marker='x')
plt.title('K-Means Clustering')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()
import pandas as pd

# 将数据转换为DataFrame
data_df = pd.DataFrame(data, columns=['Feature_1', 'Feature_2'])
labels_df = pd.DataFrame(labels, columns=['Cluster'])

# 合并特征和聚类标签
data_with_labels = pd.concat([data_df, labels_df], axis=1)

# 保存到Excel文件
excel_path = 'clustered_data.xlsx'
data_with_labels.to_excel(excel_path, index=False)

